

import React from 'react';
import DefaultComponent from './DefaultComponent';
import { NamedComponent1, NamedComponent2, NamedComponent3 } from './NamedComponent1';
import { NamedComponent2 as NamedComponent2Alias } from './NamedComponent2'
export


function App() {
  return (
    <div className="App">
      <h1>Pozdrav iz App.js!</h1>
      
      {/* Koristi DefaultComponent */}
      <DefaultComponent />

      {/* Koristi NamedComponent1 */}
      <NamedComponent1 />

      {/* Koristi NamedComponent2 */}
      <NamedComponent2 />

      {/* Koristi NamedComponent3 */}
      <NamedComponent3 />
    </div>
  );
}

export default App;
